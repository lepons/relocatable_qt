/****************************************************************************
** Meta object code from reading C++ file 'perfparser.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "parsers/perf/perfparser.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'perfparser.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PerfParser_t {
    QByteArrayData data[23];
    char stringdata0[345];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PerfParser_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PerfParser_t qt_meta_stringdata_PerfParser = {
    {
QT_MOC_LITERAL(0, 0, 10), // "PerfParser"
QT_MOC_LITERAL(1, 11, 14), // "parsingStarted"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 20), // "summaryDataAvailable"
QT_MOC_LITERAL(4, 48, 13), // "Data::Summary"
QT_MOC_LITERAL(5, 62, 4), // "data"
QT_MOC_LITERAL(6, 67, 21), // "bottomUpDataAvailable"
QT_MOC_LITERAL(7, 89, 21), // "Data::BottomUpResults"
QT_MOC_LITERAL(8, 111, 20), // "topDownDataAvailable"
QT_MOC_LITERAL(9, 132, 20), // "Data::TopDownResults"
QT_MOC_LITERAL(10, 153, 25), // "callerCalleeDataAvailable"
QT_MOC_LITERAL(11, 179, 25), // "Data::CallerCalleeResults"
QT_MOC_LITERAL(12, 205, 15), // "eventsAvailable"
QT_MOC_LITERAL(13, 221, 18), // "Data::EventResults"
QT_MOC_LITERAL(14, 240, 6), // "events"
QT_MOC_LITERAL(15, 247, 15), // "parsingFinished"
QT_MOC_LITERAL(16, 263, 13), // "parsingFailed"
QT_MOC_LITERAL(17, 277, 12), // "errorMessage"
QT_MOC_LITERAL(18, 290, 8), // "progress"
QT_MOC_LITERAL(19, 299, 13), // "stopRequested"
QT_MOC_LITERAL(20, 313, 12), // "exportFailed"
QT_MOC_LITERAL(21, 326, 14), // "exportFinished"
QT_MOC_LITERAL(22, 341, 3) // "url"

    },
    "PerfParser\0parsingStarted\0\0"
    "summaryDataAvailable\0Data::Summary\0"
    "data\0bottomUpDataAvailable\0"
    "Data::BottomUpResults\0topDownDataAvailable\0"
    "Data::TopDownResults\0callerCalleeDataAvailable\0"
    "Data::CallerCalleeResults\0eventsAvailable\0"
    "Data::EventResults\0events\0parsingFinished\0"
    "parsingFailed\0errorMessage\0progress\0"
    "stopRequested\0exportFailed\0exportFinished\0"
    "url"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PerfParser[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x06 /* Public */,
       3,    1,   75,    2, 0x06 /* Public */,
       6,    1,   78,    2, 0x06 /* Public */,
       8,    1,   81,    2, 0x06 /* Public */,
      10,    1,   84,    2, 0x06 /* Public */,
      12,    1,   87,    2, 0x06 /* Public */,
      15,    0,   90,    2, 0x06 /* Public */,
      16,    1,   91,    2, 0x06 /* Public */,
      18,    1,   94,    2, 0x06 /* Public */,
      19,    0,   97,    2, 0x06 /* Public */,
      20,    1,   98,    2, 0x06 /* Public */,
      21,    1,  101,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 7,    5,
    QMetaType::Void, 0x80000000 | 9,    5,
    QMetaType::Void, 0x80000000 | 11,    5,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::Float,   18,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::QUrl,   22,

       0        // eod
};

void PerfParser::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PerfParser *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->parsingStarted(); break;
        case 1: _t->summaryDataAvailable((*reinterpret_cast< const Data::Summary(*)>(_a[1]))); break;
        case 2: _t->bottomUpDataAvailable((*reinterpret_cast< const Data::BottomUpResults(*)>(_a[1]))); break;
        case 3: _t->topDownDataAvailable((*reinterpret_cast< const Data::TopDownResults(*)>(_a[1]))); break;
        case 4: _t->callerCalleeDataAvailable((*reinterpret_cast< const Data::CallerCalleeResults(*)>(_a[1]))); break;
        case 5: _t->eventsAvailable((*reinterpret_cast< const Data::EventResults(*)>(_a[1]))); break;
        case 6: _t->parsingFinished(); break;
        case 7: _t->parsingFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->progress((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 9: _t->stopRequested(); break;
        case 10: _t->exportFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->exportFinished((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Data::Summary >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Data::BottomUpResults >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Data::TopDownResults >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Data::CallerCalleeResults >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< Data::EventResults >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PerfParser::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::parsingStarted)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const Data::Summary & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::summaryDataAvailable)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const Data::BottomUpResults & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::bottomUpDataAvailable)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const Data::TopDownResults & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::topDownDataAvailable)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const Data::CallerCalleeResults & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::callerCalleeDataAvailable)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const Data::EventResults & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::eventsAvailable)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::parsingFinished)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::parsingFailed)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(float );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::progress)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::stopRequested)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::exportFailed)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (PerfParser::*)(const QUrl & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfParser::exportFinished)) {
                *result = 11;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject PerfParser::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_PerfParser.data,
    qt_meta_data_PerfParser,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PerfParser::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PerfParser::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PerfParser.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int PerfParser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void PerfParser::parsingStarted()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void PerfParser::summaryDataAvailable(const Data::Summary & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PerfParser::bottomUpDataAvailable(const Data::BottomUpResults & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void PerfParser::topDownDataAvailable(const Data::TopDownResults & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void PerfParser::callerCalleeDataAvailable(const Data::CallerCalleeResults & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void PerfParser::eventsAvailable(const Data::EventResults & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void PerfParser::parsingFinished()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void PerfParser::parsingFailed(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void PerfParser::progress(float _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void PerfParser::stopRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void PerfParser::exportFailed(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void PerfParser::exportFinished(const QUrl & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
