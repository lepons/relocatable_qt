/****************************************************************************
** Meta object code from reading C++ file 'recordpage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "recordpage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'recordpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RecordPage_t {
    QByteArrayData data[18];
    char stringdata0[335];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RecordPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RecordPage_t qt_meta_stringdata_RecordPage = {
    {
QT_MOC_LITERAL(0, 0, 10), // "RecordPage"
QT_MOC_LITERAL(1, 11, 17), // "homeButtonClicked"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 8), // "openFile"
QT_MOC_LITERAL(4, 39, 8), // "filePath"
QT_MOC_LITERAL(5, 48, 24), // "onApplicationNameChanged"
QT_MOC_LITERAL(6, 73, 29), // "onStartRecordingButtonClicked"
QT_MOC_LITERAL(7, 103, 7), // "checked"
QT_MOC_LITERAL(8, 111, 29), // "onWorkingDirectoryNameChanged"
QT_MOC_LITERAL(9, 141, 10), // "folderPath"
QT_MOC_LITERAL(10, 152, 36), // "onViewPerfRecordResultsButton..."
QT_MOC_LITERAL(11, 189, 23), // "onOutputFileNameChanged"
QT_MOC_LITERAL(12, 213, 22), // "onOutputFileUrlChanged"
QT_MOC_LITERAL(13, 236, 7), // "fileUrl"
QT_MOC_LITERAL(14, 244, 24), // "onOutputFileNameSelected"
QT_MOC_LITERAL(15, 269, 25), // "updateOffCpuCheckboxState"
QT_MOC_LITERAL(16, 295, 15), // "updateProcesses"
QT_MOC_LITERAL(17, 311, 23) // "updateProcessesFinished"

    },
    "RecordPage\0homeButtonClicked\0\0openFile\0"
    "filePath\0onApplicationNameChanged\0"
    "onStartRecordingButtonClicked\0checked\0"
    "onWorkingDirectoryNameChanged\0folderPath\0"
    "onViewPerfRecordResultsButtonClicked\0"
    "onOutputFileNameChanged\0onOutputFileUrlChanged\0"
    "fileUrl\0onOutputFileNameSelected\0"
    "updateOffCpuCheckboxState\0updateProcesses\0"
    "updateProcessesFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RecordPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x06 /* Public */,
       3,    1,   75,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   78,    2, 0x08 /* Private */,
       6,    1,   81,    2, 0x08 /* Private */,
       8,    1,   84,    2, 0x08 /* Private */,
      10,    0,   87,    2, 0x08 /* Private */,
      11,    1,   88,    2, 0x08 /* Private */,
      12,    1,   91,    2, 0x08 /* Private */,
      14,    1,   94,    2, 0x08 /* Private */,
      15,    0,   97,    2, 0x08 /* Private */,
      16,    0,   98,    2, 0x08 /* Private */,
      17,    0,   99,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::Bool,    7,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QUrl,   13,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void RecordPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<RecordPage *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->homeButtonClicked(); break;
        case 1: _t->openFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->onApplicationNameChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->onStartRecordingButtonClicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->onWorkingDirectoryNameChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->onViewPerfRecordResultsButtonClicked(); break;
        case 6: _t->onOutputFileNameChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->onOutputFileUrlChanged((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 8: _t->onOutputFileNameSelected((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->updateOffCpuCheckboxState(); break;
        case 10: _t->updateProcesses(); break;
        case 11: _t->updateProcessesFinished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (RecordPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RecordPage::homeButtonClicked)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (RecordPage::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RecordPage::openFile)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject RecordPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_RecordPage.data,
    qt_meta_data_RecordPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RecordPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RecordPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RecordPage.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int RecordPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void RecordPage::homeButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void RecordPage::openFile(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
