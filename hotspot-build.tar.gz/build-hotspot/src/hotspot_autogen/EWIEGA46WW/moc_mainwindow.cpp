/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[35];
    char stringdata0[423];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 13), // "openFileError"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 12), // "errorMessage"
QT_MOC_LITERAL(4, 39, 14), // "sysrootChanged"
QT_MOC_LITERAL(5, 54, 4), // "path"
QT_MOC_LITERAL(6, 59, 15), // "kallsymsChanged"
QT_MOC_LITERAL(7, 75, 17), // "debugPathsChanged"
QT_MOC_LITERAL(8, 93, 5), // "paths"
QT_MOC_LITERAL(9, 99, 20), // "extraLibPathsChanged"
QT_MOC_LITERAL(10, 120, 14), // "appPathChanged"
QT_MOC_LITERAL(11, 135, 11), // "archChanged"
QT_MOC_LITERAL(12, 147, 4), // "arch"
QT_MOC_LITERAL(13, 152, 10), // "setSysroot"
QT_MOC_LITERAL(14, 163, 11), // "setKallsyms"
QT_MOC_LITERAL(15, 175, 13), // "setDebugPaths"
QT_MOC_LITERAL(16, 189, 16), // "setExtraLibPaths"
QT_MOC_LITERAL(17, 206, 10), // "setAppPath"
QT_MOC_LITERAL(18, 217, 7), // "setArch"
QT_MOC_LITERAL(19, 225, 5), // "clear"
QT_MOC_LITERAL(20, 231, 8), // "openFile"
QT_MOC_LITERAL(21, 240, 3), // "url"
QT_MOC_LITERAL(22, 244, 6), // "reload"
QT_MOC_LITERAL(23, 251, 6), // "saveAs"
QT_MOC_LITERAL(24, 258, 23), // "onOpenFileButtonClicked"
QT_MOC_LITERAL(25, 282, 21), // "onRecordButtonClicked"
QT_MOC_LITERAL(26, 304, 19), // "onHomeButtonClicked"
QT_MOC_LITERAL(27, 324, 9), // "aboutKDAB"
QT_MOC_LITERAL(28, 334, 12), // "aboutHotspot"
QT_MOC_LITERAL(29, 347, 20), // "setCodeNavigationIDE"
QT_MOC_LITERAL(30, 368, 8), // "QAction*"
QT_MOC_LITERAL(31, 377, 6), // "action"
QT_MOC_LITERAL(32, 384, 14), // "navigateToCode"
QT_MOC_LITERAL(33, 399, 10), // "lineNumber"
QT_MOC_LITERAL(34, 410, 12) // "columnNumber"

    },
    "MainWindow\0openFileError\0\0errorMessage\0"
    "sysrootChanged\0path\0kallsymsChanged\0"
    "debugPathsChanged\0paths\0extraLibPathsChanged\0"
    "appPathChanged\0archChanged\0arch\0"
    "setSysroot\0setKallsyms\0setDebugPaths\0"
    "setExtraLibPaths\0setAppPath\0setArch\0"
    "clear\0openFile\0url\0reload\0saveAs\0"
    "onOpenFileButtonClicked\0onRecordButtonClicked\0"
    "onHomeButtonClicked\0aboutKDAB\0"
    "aboutHotspot\0setCodeNavigationIDE\0"
    "QAction*\0action\0navigateToCode\0"
    "lineNumber\0columnNumber"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  139,    2, 0x06 /* Public */,
       4,    1,  142,    2, 0x06 /* Public */,
       6,    1,  145,    2, 0x06 /* Public */,
       7,    1,  148,    2, 0x06 /* Public */,
       9,    1,  151,    2, 0x06 /* Public */,
      10,    1,  154,    2, 0x06 /* Public */,
      11,    1,  157,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    1,  160,    2, 0x0a /* Public */,
      14,    1,  163,    2, 0x0a /* Public */,
      15,    1,  166,    2, 0x0a /* Public */,
      16,    1,  169,    2, 0x0a /* Public */,
      17,    1,  172,    2, 0x0a /* Public */,
      18,    1,  175,    2, 0x0a /* Public */,
      19,    0,  178,    2, 0x0a /* Public */,
      20,    1,  179,    2, 0x0a /* Public */,
      20,    1,  182,    2, 0x0a /* Public */,
      22,    0,  185,    2, 0x0a /* Public */,
      23,    0,  186,    2, 0x0a /* Public */,
      24,    0,  187,    2, 0x0a /* Public */,
      25,    0,  188,    2, 0x0a /* Public */,
      26,    0,  189,    2, 0x0a /* Public */,
      27,    0,  190,    2, 0x0a /* Public */,
      28,    0,  191,    2, 0x0a /* Public */,
      29,    1,  192,    2, 0x0a /* Public */,
      32,    3,  195,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,   12,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QUrl,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 30,   31,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int,   21,   33,   34,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->openFileError((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->sysrootChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->kallsymsChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->debugPathsChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->extraLibPathsChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->appPathChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->archChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->setSysroot((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->setKallsyms((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->setDebugPaths((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->setExtraLibPaths((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->setAppPath((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: _t->setArch((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->clear(); break;
        case 14: _t->openFile((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->openFile((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 16: _t->reload(); break;
        case 17: _t->saveAs(); break;
        case 18: _t->onOpenFileButtonClicked(); break;
        case 19: _t->onRecordButtonClicked(); break;
        case 20: _t->onHomeButtonClicked(); break;
        case 21: _t->aboutKDAB(); break;
        case 22: _t->aboutHotspot(); break;
        case 23: _t->setCodeNavigationIDE((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 24: _t->navigateToCode((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::openFileError)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::sysrootChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::kallsymsChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::debugPathsChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::extraLibPathsChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::appPathChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::archChanged)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 25;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::openFileError(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::sysrootChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::kallsymsChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::debugPathsChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MainWindow::extraLibPathsChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MainWindow::appPathChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MainWindow::archChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
