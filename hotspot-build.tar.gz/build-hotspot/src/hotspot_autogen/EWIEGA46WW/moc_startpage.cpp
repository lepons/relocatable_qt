/****************************************************************************
** Meta object code from reading C++ file 'startpage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "startpage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'startpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_StartPage_t {
    QByteArrayData data[9];
    char stringdata0[133];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_StartPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_StartPage_t qt_meta_stringdata_StartPage = {
    {
QT_MOC_LITERAL(0, 0, 9), // "StartPage"
QT_MOC_LITERAL(1, 10, 21), // "openFileButtonClicked"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 19), // "recordButtonClicked"
QT_MOC_LITERAL(4, 53, 22), // "stopParseButtonClicked"
QT_MOC_LITERAL(5, 76, 15), // "onOpenFileError"
QT_MOC_LITERAL(6, 92, 12), // "errorMessage"
QT_MOC_LITERAL(7, 105, 19), // "onParseFileProgress"
QT_MOC_LITERAL(8, 125, 7) // "percent"

    },
    "StartPage\0openFileButtonClicked\0\0"
    "recordButtonClicked\0stopParseButtonClicked\0"
    "onOpenFileError\0errorMessage\0"
    "onParseFileProgress\0percent"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_StartPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   39,    2, 0x06 /* Public */,
       3,    0,   40,    2, 0x06 /* Public */,
       4,    0,   41,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   42,    2, 0x0a /* Public */,
       7,    1,   45,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::Float,    8,

       0        // eod
};

void StartPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StartPage *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->openFileButtonClicked(); break;
        case 1: _t->recordButtonClicked(); break;
        case 2: _t->stopParseButtonClicked(); break;
        case 3: _t->onOpenFileError((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->onParseFileProgress((*reinterpret_cast< float(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (StartPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StartPage::openFileButtonClicked)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (StartPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StartPage::recordButtonClicked)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (StartPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&StartPage::stopParseButtonClicked)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject StartPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_StartPage.data,
    qt_meta_data_StartPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *StartPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StartPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_StartPage.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int StartPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void StartPage::openFileButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void StartPage::recordButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void StartPage::stopParseButtonClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
