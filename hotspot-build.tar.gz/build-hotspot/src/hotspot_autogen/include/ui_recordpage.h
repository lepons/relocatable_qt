/********************************************************************************
** Form generated from reading UI file 'recordpage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECORDPAGE_H
#define UI_RECORDPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "kcollapsiblegroupbox.h"
#include "kmessagewidget.h"
#include "kurlrequester.h"

QT_BEGIN_NAMESPACE

class Ui_RecordPage
{
public:
    QVBoxLayout *verticalLayout_14;
    QHBoxLayout *recordTypeLayout;
    QComboBox *recordTypeComboBox;
    QSpacerItem *recordTypeLayoutHorizontalSpacer;
    QPushButton *homeButton;
    QGroupBox *launchAppBox;
    QFormLayout *formLayout_1;
    QLabel *applicationLabel;
    KUrlComboRequester *applicationName;
    QLabel *applicationParamsLabel;
    QLineEdit *applicationParametersBox;
    QLabel *workingDirectoryLabel;
    KUrlRequester *workingDirectory;
    QGroupBox *attachAppBox;
    QFormLayout *formLayout_2;
    QLabel *processesFilterLabel;
    QLineEdit *processesFilterBox;
    QLabel *processesLabel;
    QTreeView *processesTableView;
    QGroupBox *perfOptionsBox;
    QFormLayout *formLayout;
    QLabel *eventTypeLabel;
    QComboBox *eventTypeBox;
    QLabel *elevatePrivilegesLabel;
    QCheckBox *elevatePrivilegesCheckBox;
    QLabel *offCpuLabel;
    QCheckBox *offCpuCheckBox;
    KCollapsibleGroupBox *perfOptionsBox2;
    QFormLayout *formLayout_3;
    QLabel *outputFileLabel;
    KUrlRequester *outputFile;
    QLabel *unwindingMethodLabel;
    QComboBox *callGraphComboBox;
    QLabel *sampleCpuLabel;
    QCheckBox *sampleCpuCheckBox;
    QLabel *useAioLabel;
    QCheckBox *useAioCheckBox;
    QLabel *bufferSizeLabel;
    QWidget *mmapPagesContainer;
    QHBoxLayout *horizontalLayout_2;
    QSpinBox *mmapPagesSpinBox;
    QComboBox *mmapPagesUnitComboBox;
    QSpacerItem *horizontalSpacer;
    QLabel *compressionLabel;
    QComboBox *compressionComboBox;
    QLabel *perfParamsLabel;
    QComboBox *perfParams;
    KMessageWidget *applicationRecordErrorMessage;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *startRecordingButton;
    QPushButton *viewPerfRecordResultsButton;
    QGroupBox *recordOutputBox;
    QVBoxLayout *verticalLayout;
    QTextEdit *perfResultsTextEdit;
    QLineEdit *perfInputEdit;

    void setupUi(QWidget *RecordPage)
    {
        if (RecordPage->objectName().isEmpty())
            RecordPage->setObjectName(QString::fromUtf8("RecordPage"));
        RecordPage->resize(1120, 967);
        verticalLayout_14 = new QVBoxLayout(RecordPage);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        recordTypeLayout = new QHBoxLayout();
        recordTypeLayout->setObjectName(QString::fromUtf8("recordTypeLayout"));
        recordTypeComboBox = new QComboBox(RecordPage);
        recordTypeComboBox->setObjectName(QString::fromUtf8("recordTypeComboBox"));

        recordTypeLayout->addWidget(recordTypeComboBox);

        recordTypeLayoutHorizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        recordTypeLayout->addItem(recordTypeLayoutHorizontalSpacer);

        homeButton = new QPushButton(RecordPage);
        homeButton->setObjectName(QString::fromUtf8("homeButton"));
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("go-home");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        homeButton->setIcon(icon);

        recordTypeLayout->addWidget(homeButton);


        verticalLayout_14->addLayout(recordTypeLayout);

        launchAppBox = new QGroupBox(RecordPage);
        launchAppBox->setObjectName(QString::fromUtf8("launchAppBox"));
        formLayout_1 = new QFormLayout(launchAppBox);
        formLayout_1->setObjectName(QString::fromUtf8("formLayout_1"));
        formLayout_1->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        applicationLabel = new QLabel(launchAppBox);
        applicationLabel->setObjectName(QString::fromUtf8("applicationLabel"));

        formLayout_1->setWidget(0, QFormLayout::LabelRole, applicationLabel);

        applicationName = new KUrlComboRequester(launchAppBox);
        applicationName->setObjectName(QString::fromUtf8("applicationName"));

        formLayout_1->setWidget(0, QFormLayout::FieldRole, applicationName);

        applicationParamsLabel = new QLabel(launchAppBox);
        applicationParamsLabel->setObjectName(QString::fromUtf8("applicationParamsLabel"));

        formLayout_1->setWidget(1, QFormLayout::LabelRole, applicationParamsLabel);

        applicationParametersBox = new QLineEdit(launchAppBox);
        applicationParametersBox->setObjectName(QString::fromUtf8("applicationParametersBox"));
        applicationParametersBox->setContextMenuPolicy(Qt::NoContextMenu);

        formLayout_1->setWidget(1, QFormLayout::FieldRole, applicationParametersBox);

        workingDirectoryLabel = new QLabel(launchAppBox);
        workingDirectoryLabel->setObjectName(QString::fromUtf8("workingDirectoryLabel"));

        formLayout_1->setWidget(2, QFormLayout::LabelRole, workingDirectoryLabel);

        workingDirectory = new KUrlRequester(launchAppBox);
        workingDirectory->setObjectName(QString::fromUtf8("workingDirectory"));

        formLayout_1->setWidget(2, QFormLayout::FieldRole, workingDirectory);


        verticalLayout_14->addWidget(launchAppBox);

        attachAppBox = new QGroupBox(RecordPage);
        attachAppBox->setObjectName(QString::fromUtf8("attachAppBox"));
        formLayout_2 = new QFormLayout(attachAppBox);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        formLayout_2->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        processesFilterLabel = new QLabel(attachAppBox);
        processesFilterLabel->setObjectName(QString::fromUtf8("processesFilterLabel"));

        formLayout_2->setWidget(0, QFormLayout::LabelRole, processesFilterLabel);

        processesFilterBox = new QLineEdit(attachAppBox);
        processesFilterBox->setObjectName(QString::fromUtf8("processesFilterBox"));

        formLayout_2->setWidget(0, QFormLayout::FieldRole, processesFilterBox);

        processesLabel = new QLabel(attachAppBox);
        processesLabel->setObjectName(QString::fromUtf8("processesLabel"));

        formLayout_2->setWidget(1, QFormLayout::LabelRole, processesLabel);

        processesTableView = new QTreeView(attachAppBox);
        processesTableView->setObjectName(QString::fromUtf8("processesTableView"));
        processesTableView->setAlternatingRowColors(true);
        processesTableView->setRootIsDecorated(false);
        processesTableView->setUniformRowHeights(true);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, processesTableView);


        verticalLayout_14->addWidget(attachAppBox);

        perfOptionsBox = new QGroupBox(RecordPage);
        perfOptionsBox->setObjectName(QString::fromUtf8("perfOptionsBox"));
        formLayout = new QFormLayout(perfOptionsBox);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        eventTypeLabel = new QLabel(perfOptionsBox);
        eventTypeLabel->setObjectName(QString::fromUtf8("eventTypeLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, eventTypeLabel);

        eventTypeBox = new QComboBox(perfOptionsBox);
        eventTypeBox->setObjectName(QString::fromUtf8("eventTypeBox"));
        eventTypeBox->setEditable(true);

        formLayout->setWidget(0, QFormLayout::FieldRole, eventTypeBox);

        elevatePrivilegesLabel = new QLabel(perfOptionsBox);
        elevatePrivilegesLabel->setObjectName(QString::fromUtf8("elevatePrivilegesLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, elevatePrivilegesLabel);

        elevatePrivilegesCheckBox = new QCheckBox(perfOptionsBox);
        elevatePrivilegesCheckBox->setObjectName(QString::fromUtf8("elevatePrivilegesCheckBox"));

        formLayout->setWidget(1, QFormLayout::FieldRole, elevatePrivilegesCheckBox);

        offCpuLabel = new QLabel(perfOptionsBox);
        offCpuLabel->setObjectName(QString::fromUtf8("offCpuLabel"));

        formLayout->setWidget(2, QFormLayout::LabelRole, offCpuLabel);

        offCpuCheckBox = new QCheckBox(perfOptionsBox);
        offCpuCheckBox->setObjectName(QString::fromUtf8("offCpuCheckBox"));

        formLayout->setWidget(2, QFormLayout::FieldRole, offCpuCheckBox);

        perfOptionsBox2 = new KCollapsibleGroupBox(perfOptionsBox);
        perfOptionsBox2->setObjectName(QString::fromUtf8("perfOptionsBox2"));
        formLayout_3 = new QFormLayout(perfOptionsBox2);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        formLayout_3->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        outputFileLabel = new QLabel(perfOptionsBox2);
        outputFileLabel->setObjectName(QString::fromUtf8("outputFileLabel"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, outputFileLabel);

        outputFile = new KUrlRequester(perfOptionsBox2);
        outputFile->setObjectName(QString::fromUtf8("outputFile"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, outputFile);

        unwindingMethodLabel = new QLabel(perfOptionsBox2);
        unwindingMethodLabel->setObjectName(QString::fromUtf8("unwindingMethodLabel"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, unwindingMethodLabel);

        callGraphComboBox = new QComboBox(perfOptionsBox2);
        callGraphComboBox->setObjectName(QString::fromUtf8("callGraphComboBox"));

        formLayout_3->setWidget(1, QFormLayout::FieldRole, callGraphComboBox);

        sampleCpuLabel = new QLabel(perfOptionsBox2);
        sampleCpuLabel->setObjectName(QString::fromUtf8("sampleCpuLabel"));

        formLayout_3->setWidget(2, QFormLayout::LabelRole, sampleCpuLabel);

        sampleCpuCheckBox = new QCheckBox(perfOptionsBox2);
        sampleCpuCheckBox->setObjectName(QString::fromUtf8("sampleCpuCheckBox"));
        sampleCpuCheckBox->setChecked(true);

        formLayout_3->setWidget(2, QFormLayout::FieldRole, sampleCpuCheckBox);

        useAioLabel = new QLabel(perfOptionsBox2);
        useAioLabel->setObjectName(QString::fromUtf8("useAioLabel"));

        formLayout_3->setWidget(3, QFormLayout::LabelRole, useAioLabel);

        useAioCheckBox = new QCheckBox(perfOptionsBox2);
        useAioCheckBox->setObjectName(QString::fromUtf8("useAioCheckBox"));

        formLayout_3->setWidget(3, QFormLayout::FieldRole, useAioCheckBox);

        bufferSizeLabel = new QLabel(perfOptionsBox2);
        bufferSizeLabel->setObjectName(QString::fromUtf8("bufferSizeLabel"));

        formLayout_3->setWidget(4, QFormLayout::LabelRole, bufferSizeLabel);

        mmapPagesContainer = new QWidget(perfOptionsBox2);
        mmapPagesContainer->setObjectName(QString::fromUtf8("mmapPagesContainer"));
        horizontalLayout_2 = new QHBoxLayout(mmapPagesContainer);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        mmapPagesSpinBox = new QSpinBox(mmapPagesContainer);
        mmapPagesSpinBox->setObjectName(QString::fromUtf8("mmapPagesSpinBox"));
        mmapPagesSpinBox->setMaximum(999);

        horizontalLayout_2->addWidget(mmapPagesSpinBox);

        mmapPagesUnitComboBox = new QComboBox(mmapPagesContainer);
        mmapPagesUnitComboBox->addItem(QString());
        mmapPagesUnitComboBox->addItem(QString());
        mmapPagesUnitComboBox->addItem(QString());
        mmapPagesUnitComboBox->addItem(QString());
        mmapPagesUnitComboBox->addItem(QString());
        mmapPagesUnitComboBox->setObjectName(QString::fromUtf8("mmapPagesUnitComboBox"));

        horizontalLayout_2->addWidget(mmapPagesUnitComboBox);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);


        formLayout_3->setWidget(4, QFormLayout::FieldRole, mmapPagesContainer);

        compressionLabel = new QLabel(perfOptionsBox2);
        compressionLabel->setObjectName(QString::fromUtf8("compressionLabel"));

        formLayout_3->setWidget(5, QFormLayout::LabelRole, compressionLabel);

        compressionComboBox = new QComboBox(perfOptionsBox2);
        compressionComboBox->setObjectName(QString::fromUtf8("compressionComboBox"));

        formLayout_3->setWidget(5, QFormLayout::FieldRole, compressionComboBox);

        perfParamsLabel = new QLabel(perfOptionsBox2);
        perfParamsLabel->setObjectName(QString::fromUtf8("perfParamsLabel"));

        formLayout_3->setWidget(6, QFormLayout::LabelRole, perfParamsLabel);

        perfParams = new QComboBox(perfOptionsBox2);
        perfParams->setObjectName(QString::fromUtf8("perfParams"));
        perfParams->setEditable(true);

        formLayout_3->setWidget(6, QFormLayout::FieldRole, perfParams);


        formLayout->setWidget(3, QFormLayout::SpanningRole, perfOptionsBox2);


        verticalLayout_14->addWidget(perfOptionsBox);

        applicationRecordErrorMessage = new KMessageWidget(RecordPage);
        applicationRecordErrorMessage->setObjectName(QString::fromUtf8("applicationRecordErrorMessage"));

        verticalLayout_14->addWidget(applicationRecordErrorMessage);

        widget = new QWidget(RecordPage);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        startRecordingButton = new QPushButton(widget);
        startRecordingButton->setObjectName(QString::fromUtf8("startRecordingButton"));
        QIcon icon1;
        iconThemeName = QString::fromUtf8("media-playback-start");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon1 = QIcon::fromTheme(iconThemeName);
        } else {
            icon1.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        startRecordingButton->setIcon(icon1);
        startRecordingButton->setCheckable(true);
        startRecordingButton->setAutoDefault(true);

        horizontalLayout->addWidget(startRecordingButton);

        viewPerfRecordResultsButton = new QPushButton(widget);
        viewPerfRecordResultsButton->setObjectName(QString::fromUtf8("viewPerfRecordResultsButton"));
        viewPerfRecordResultsButton->setEnabled(false);
        QIcon icon2;
        iconThemeName = QString::fromUtf8("view-list-symbolic");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon2 = QIcon::fromTheme(iconThemeName);
        } else {
            icon2.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        viewPerfRecordResultsButton->setIcon(icon2);
        viewPerfRecordResultsButton->setAutoDefault(true);

        horizontalLayout->addWidget(viewPerfRecordResultsButton);


        verticalLayout_14->addWidget(widget);

        recordOutputBox = new QGroupBox(RecordPage);
        recordOutputBox->setObjectName(QString::fromUtf8("recordOutputBox"));
        verticalLayout = new QVBoxLayout(recordOutputBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        perfResultsTextEdit = new QTextEdit(recordOutputBox);
        perfResultsTextEdit->setObjectName(QString::fromUtf8("perfResultsTextEdit"));
        QFont font;
        font.setFamily(QString::fromUtf8("Monospace"));
        perfResultsTextEdit->setFont(font);
        perfResultsTextEdit->setReadOnly(true);

        verticalLayout->addWidget(perfResultsTextEdit);

        perfInputEdit = new QLineEdit(recordOutputBox);
        perfInputEdit->setObjectName(QString::fromUtf8("perfInputEdit"));
        perfInputEdit->setEnabled(false);

        verticalLayout->addWidget(perfInputEdit);


        verticalLayout_14->addWidget(recordOutputBox);

#if QT_CONFIG(shortcut)
        applicationLabel->setBuddy(applicationName);
        applicationParamsLabel->setBuddy(applicationParametersBox);
        workingDirectoryLabel->setBuddy(workingDirectory);
        processesFilterLabel->setBuddy(processesFilterBox);
        processesLabel->setBuddy(processesTableView);
        eventTypeLabel->setBuddy(eventTypeBox);
        elevatePrivilegesLabel->setBuddy(elevatePrivilegesCheckBox);
        offCpuLabel->setBuddy(offCpuCheckBox);
        outputFileLabel->setBuddy(outputFile);
        unwindingMethodLabel->setBuddy(callGraphComboBox);
        sampleCpuLabel->setBuddy(sampleCpuCheckBox);
        useAioLabel->setBuddy(useAioCheckBox);
        bufferSizeLabel->setBuddy(mmapPagesSpinBox);
        compressionLabel->setBuddy(compressionComboBox);
        perfParamsLabel->setBuddy(perfParams);
#endif // QT_CONFIG(shortcut)

        retranslateUi(RecordPage);

        mmapPagesUnitComboBox->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(RecordPage);
    } // setupUi

    void retranslateUi(QWidget *RecordPage)
    {
#if QT_CONFIG(tooltip)
        recordTypeComboBox->setToolTip(QCoreApplication::translate("RecordPage", "Select recording type", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        homeButton->setToolTip(QCoreApplication::translate("RecordPage", "Go to start screen", nullptr));
#endif // QT_CONFIG(tooltip)
        homeButton->setText(QCoreApplication::translate("RecordPage", "Home", nullptr));
        launchAppBox->setTitle(QCoreApplication::translate("RecordPage", "Launch Application", nullptr));
#if QT_CONFIG(tooltip)
        applicationLabel->setToolTip(QCoreApplication::translate("RecordPage", "Path to the application to be recorded", nullptr));
#endif // QT_CONFIG(tooltip)
        applicationLabel->setText(QCoreApplication::translate("RecordPage", "App&lication:", nullptr));
#if QT_CONFIG(tooltip)
        applicationName->setToolTip(QCoreApplication::translate("RecordPage", "Path to the application to be recorded", nullptr));
#endif // QT_CONFIG(tooltip)
        applicationName->setText(QString());
#if QT_CONFIG(tooltip)
        applicationParamsLabel->setToolTip(QCoreApplication::translate("RecordPage", "Optional parameters to pass to the application being recorded", nullptr));
#endif // QT_CONFIG(tooltip)
        applicationParamsLabel->setText(QCoreApplication::translate("RecordPage", "Parame&ters:", nullptr));
#if QT_CONFIG(tooltip)
        applicationParametersBox->setToolTip(QCoreApplication::translate("RecordPage", "Optional parameters to pass to the application being recorded", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        workingDirectoryLabel->setToolTip(QCoreApplication::translate("RecordPage", "Directory to store the perf data file while recording", nullptr));
#endif // QT_CONFIG(tooltip)
        workingDirectoryLabel->setText(QCoreApplication::translate("RecordPage", "Wor&king Directory:", nullptr));
#if QT_CONFIG(tooltip)
        workingDirectory->setToolTip(QCoreApplication::translate("RecordPage", "Directory to store the perf data file while recording", nullptr));
#endif // QT_CONFIG(tooltip)
        attachAppBox->setTitle(QCoreApplication::translate("RecordPage", "Attach To Application", nullptr));
#if QT_CONFIG(tooltip)
        processesFilterLabel->setToolTip(QCoreApplication::translate("RecordPage", "Filter the process list by process name or process ID", nullptr));
#endif // QT_CONFIG(tooltip)
        processesFilterLabel->setText(QCoreApplication::translate("RecordPage", "Process Filter:", nullptr));
#if QT_CONFIG(tooltip)
        processesFilterBox->setToolTip(QCoreApplication::translate("RecordPage", "Filter the process list by process name or process ID", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        processesLabel->setToolTip(QCoreApplication::translate("RecordPage", "List of processes. Select at least one to attach to.", nullptr));
#endif // QT_CONFIG(tooltip)
        processesLabel->setText(QCoreApplication::translate("RecordPage", "Processes:", nullptr));
#if QT_CONFIG(tooltip)
        processesTableView->setToolTip(QCoreApplication::translate("RecordPage", "List of processes. Select at least one to attach to.", nullptr));
#endif // QT_CONFIG(tooltip)
        perfOptionsBox->setTitle(QCoreApplication::translate("RecordPage", "Perf Options", nullptr));
#if QT_CONFIG(tooltip)
        eventTypeLabel->setToolTip(QCoreApplication::translate("RecordPage", "Optional perf event type flags to use while recording perf data", nullptr));
#endif // QT_CONFIG(tooltip)
        eventTypeLabel->setText(QCoreApplication::translate("RecordPage", "Event &Type(s):", nullptr));
#if QT_CONFIG(tooltip)
        eventTypeBox->setToolTip(QCoreApplication::translate("RecordPage", "Optional perf event type flags to use while recording perf data", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        elevatePrivilegesLabel->setToolTip(QCoreApplication::translate("RecordPage", "When enabled, hotspot will temporarily elevate the perf privileges via pkexec, kdesudo or kdesu. This allows you to access advanced perf features such as kernel tracepoints required for Off-CPU profiling.", nullptr));
#endif // QT_CONFIG(tooltip)
        elevatePrivilegesLabel->setText(QCoreApplication::translate("RecordPage", "Elevate Privileges:", nullptr));
#if QT_CONFIG(tooltip)
        elevatePrivilegesCheckBox->setToolTip(QCoreApplication::translate("RecordPage", "When enabled, hotspot will temporarily elevate the perf privileges via pkexec, kdesudo or kdesu. This allows you to access advanced perf features such as kernel tracepoints required for Off-CPU profiling.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        offCpuLabel->setToolTip(QCoreApplication::translate("RecordPage", "Record scheduler switch events. This enables off-CPU profiling to measure sleep times etc. This requires elevated privileges.", nullptr));
#endif // QT_CONFIG(tooltip)
        offCpuLabel->setText(QCoreApplication::translate("RecordPage", "Off-CPU Profilin&g:", nullptr));
#if QT_CONFIG(tooltip)
        offCpuCheckBox->setToolTip(QCoreApplication::translate("RecordPage", "Record scheduler switch events. This enables off-CPU profiling to measure sleep times etc. This requires elevated privileges.", nullptr));
#endif // QT_CONFIG(tooltip)
        offCpuCheckBox->setText(QString());
        perfOptionsBox2->setTitle(QCoreApplication::translate("RecordPage", "Advanced", nullptr));
#if QT_CONFIG(tooltip)
        outputFileLabel->setToolTip(QCoreApplication::translate("RecordPage", "Path to the file location, where perf will write its output to", nullptr));
#endif // QT_CONFIG(tooltip)
        outputFileLabel->setText(QCoreApplication::translate("RecordPage", "O&utput File:", nullptr));
#if QT_CONFIG(tooltip)
        outputFile->setToolTip(QCoreApplication::translate("RecordPage", "Path to the file location, where perf will write its output to", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        unwindingMethodLabel->setToolTip(QCoreApplication::translate("RecordPage", "Preferred unwinding method to use while recording perf data", nullptr));
#endif // QT_CONFIG(tooltip)
        unwindingMethodLabel->setText(QCoreApplication::translate("RecordPage", "&Unwinding Method:", nullptr));
#if QT_CONFIG(tooltip)
        callGraphComboBox->setToolTip(QCoreApplication::translate("RecordPage", "Preferred unwinding method to use while recording perf data", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        sampleCpuLabel->setToolTip(QCoreApplication::translate("RecordPage", "Record the CPU where an event occurred. This enables the per-CPU event timeline. When this setting is disabled, all events will appear to be associated with CPU #0.", nullptr));
#endif // QT_CONFIG(tooltip)
        sampleCpuLabel->setText(QCoreApplication::translate("RecordPage", "Per-CPU Events:", nullptr));
#if QT_CONFIG(tooltip)
        sampleCpuCheckBox->setToolTip(QCoreApplication::translate("RecordPage", "Record the CPU where an event occurred. This enables the per-CPU event timeline. When this setting is disabled, all events will appear to be associated with CPU #0.", nullptr));
#endif // QT_CONFIG(tooltip)
        sampleCpuCheckBox->setText(QString());
#if QT_CONFIG(tooltip)
        useAioLabel->setToolTip(QCoreApplication::translate("RecordPage", "<qt>Use asynchronous (Posix AIO) trace writing mode. Asynchronous mode is supported only when linking Perf tool with libc library providing implementation for Posix AIO API.</qt>", nullptr));
#endif // QT_CONFIG(tooltip)
        useAioLabel->setText(QCoreApplication::translate("RecordPage", "Use AIO:", nullptr));
#if QT_CONFIG(tooltip)
        useAioCheckBox->setToolTip(QCoreApplication::translate("RecordPage", "<qt>Use asynchronous (Posix AIO) trace writing mode. Asynchronous mode is supported only when linking Perf tool with libc library providing implementation for Posix AIO API.</qt>", nullptr));
#endif // QT_CONFIG(tooltip)
        useAioCheckBox->setText(QString());
#if QT_CONFIG(tooltip)
        bufferSizeLabel->setToolTip(QCoreApplication::translate("RecordPage", "Set the event buffer size. Increase this value when events are lost during recording. When a byte units is selected, the size is rounded up to have nearest pages power of two value. The number of data pages gets rounded up to the nearest power of two.", nullptr));
#endif // QT_CONFIG(tooltip)
        bufferSizeLabel->setText(QCoreApplication::translate("RecordPage", "Buffer Si&ze:", nullptr));
#if QT_CONFIG(tooltip)
        mmapPagesSpinBox->setToolTip(QCoreApplication::translate("RecordPage", "Set the event buffer size. Increase this value when events are lost during recording. When a byte units is selected, the size is rounded up to have nearest pages power of two value. The number of data pages gets rounded up to the nearest power of two.", nullptr));
#endif // QT_CONFIG(tooltip)
        mmapPagesSpinBox->setSpecialValueText(QCoreApplication::translate("RecordPage", "automatic", nullptr));
        mmapPagesUnitComboBox->setItemText(0, QCoreApplication::translate("RecordPage", "B", nullptr));
        mmapPagesUnitComboBox->setItemText(1, QCoreApplication::translate("RecordPage", "KB", nullptr));
        mmapPagesUnitComboBox->setItemText(2, QCoreApplication::translate("RecordPage", "MB", nullptr));
        mmapPagesUnitComboBox->setItemText(3, QCoreApplication::translate("RecordPage", "GB", nullptr));
        mmapPagesUnitComboBox->setItemText(4, QCoreApplication::translate("RecordPage", "Pages", nullptr));

#if QT_CONFIG(tooltip)
        mmapPagesUnitComboBox->setToolTip(QCoreApplication::translate("RecordPage", "Select the unit of buffer size. When a byte units is selected, the size is rounded up to have nearest pages power of two value. The number of data pages gets rounded up to the nearest power of two.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        compressionLabel->setToolTip(QCoreApplication::translate("RecordPage", "<qt>Compression using zstd will drastically reduce the size of <tt>perf.data</tt> files. It is recommended to keep this option enabled. The default uses a fast compression level which already yields very significant space savings. If desired, you can select a slower compression level to save more disk space.</qt>", nullptr));
#endif // QT_CONFIG(tooltip)
        compressionLabel->setText(QCoreApplication::translate("RecordPage", "Compression:", nullptr));
#if QT_CONFIG(tooltip)
        compressionComboBox->setToolTip(QCoreApplication::translate("RecordPage", "<qt>Compression using zstd will drastically reduce the size of <tt>perf.data</tt> files. It is recommended to keep this option enabled. The default uses a fast compression level which already yields very significant space savings. If desired, you can select a slower compression level to save more disk space.</qt>", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        perfParamsLabel->setToolTip(QCoreApplication::translate("RecordPage", "<html><head/><body><p>Free-form entry field for custom perf parameters. Use this field to set advanced options (cf. <tt>man perf record</tt>).</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        perfParamsLabel->setText(QCoreApplication::translate("RecordPage", "Advanced Options:", nullptr));
#if QT_CONFIG(tooltip)
        perfParams->setToolTip(QCoreApplication::translate("RecordPage", "<html><head/><body><p>Free-form entry field for custom perf parameters. Use this field to set advanced options (cf. <tt>man perf record</tt>).</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        startRecordingButton->setToolTip(QCoreApplication::translate("RecordPage", "Start recording perf data", nullptr));
#endif // QT_CONFIG(tooltip)
        startRecordingButton->setText(QCoreApplication::translate("RecordPage", "Start Recording", nullptr));
#if QT_CONFIG(tooltip)
        viewPerfRecordResultsButton->setToolTip(QCoreApplication::translate("RecordPage", "View the perf record results", nullptr));
#endif // QT_CONFIG(tooltip)
        viewPerfRecordResultsButton->setText(QCoreApplication::translate("RecordPage", "View Results", nullptr));
        recordOutputBox->setTitle(QCoreApplication::translate("RecordPage", "Record Output", nullptr));
#if QT_CONFIG(tooltip)
        perfResultsTextEdit->setToolTip(QCoreApplication::translate("RecordPage", "Detailed output from the perf record operation.", nullptr));
#endif // QT_CONFIG(tooltip)
        perfResultsTextEdit->setPlaceholderText(QCoreApplication::translate("RecordPage", "Waiting for recording to start...", nullptr));
        perfInputEdit->setPlaceholderText(QCoreApplication::translate("RecordPage", "send input to process...", nullptr));
        (void)RecordPage;
    } // retranslateUi

};

namespace Ui {
    class RecordPage: public Ui_RecordPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECORDPAGE_H
