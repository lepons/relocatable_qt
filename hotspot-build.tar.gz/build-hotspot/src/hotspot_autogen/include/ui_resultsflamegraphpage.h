/********************************************************************************
** Form generated from reading UI file 'resultsflamegraphpage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSFLAMEGRAPHPAGE_H
#define UI_RESULTSFLAMEGRAPHPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "flamegraph.h"

QT_BEGIN_NAMESPACE

class Ui_ResultsFlameGraphPage
{
public:
    QVBoxLayout *verticalLayout;
    FlameGraph *flameGraph;

    void setupUi(QWidget *ResultsFlameGraphPage)
    {
        if (ResultsFlameGraphPage->objectName().isEmpty())
            ResultsFlameGraphPage->setObjectName(QString::fromUtf8("ResultsFlameGraphPage"));
        ResultsFlameGraphPage->resize(0, 10);
        verticalLayout = new QVBoxLayout(ResultsFlameGraphPage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        flameGraph = new FlameGraph(ResultsFlameGraphPage);
        flameGraph->setObjectName(QString::fromUtf8("flameGraph"));

        verticalLayout->addWidget(flameGraph);


        retranslateUi(ResultsFlameGraphPage);

        QMetaObject::connectSlotsByName(ResultsFlameGraphPage);
    } // setupUi

    void retranslateUi(QWidget *ResultsFlameGraphPage)
    {
#if QT_CONFIG(tooltip)
        ResultsFlameGraphPage->setToolTip(QCoreApplication::translate("ResultsFlameGraphPage", "Visualize the aggregated call-graph profile data in flame graph.", nullptr));
#endif // QT_CONFIG(tooltip)
    } // retranslateUi

};

namespace Ui {
    class ResultsFlameGraphPage: public Ui_ResultsFlameGraphPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSFLAMEGRAPHPAGE_H
