/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionAbout_Hotspot;
    QAction *actionAbout_KDAB;
    QAction *actionAbout_Qt;
    QWidget *centralWidget;
    QMenuBar *menuBar;
    QMenu *helpMenu;
    QMenu *fileMenu;
    QMenu *settingsMenu;
    QMenu *viewMenu;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1123, 769);
        actionAbout_Hotspot = new QAction(MainWindow);
        actionAbout_Hotspot->setObjectName(QString::fromUtf8("actionAbout_Hotspot"));
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("hotspot");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QString::fromUtf8(":/images/icons/128-apps-hotspot.png"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionAbout_Hotspot->setIcon(icon);
        actionAbout_KDAB = new QAction(MainWindow);
        actionAbout_KDAB->setObjectName(QString::fromUtf8("actionAbout_KDAB"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/kdablogo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout_KDAB->setIcon(icon1);
        actionAbout_Qt = new QAction(MainWindow);
        actionAbout_Qt->setObjectName(QString::fromUtf8("actionAbout_Qt"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/qtlogo.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionAbout_Qt->setIcon(icon2);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setEnabled(true);
        menuBar->setGeometry(QRect(0, 0, 1123, 29));
        helpMenu = new QMenu(menuBar);
        helpMenu->setObjectName(QString::fromUtf8("helpMenu"));
        fileMenu = new QMenu(menuBar);
        fileMenu->setObjectName(QString::fromUtf8("fileMenu"));
        settingsMenu = new QMenu(menuBar);
        settingsMenu->setObjectName(QString::fromUtf8("settingsMenu"));
        viewMenu = new QMenu(menuBar);
        viewMenu->setObjectName(QString::fromUtf8("viewMenu"));
        viewMenu->setToolTipsVisible(true);
        MainWindow->setMenuBar(menuBar);

        menuBar->addAction(fileMenu->menuAction());
        menuBar->addAction(settingsMenu->menuAction());
        menuBar->addAction(viewMenu->menuAction());
        menuBar->addAction(helpMenu->menuAction());
        helpMenu->addAction(actionAbout_Hotspot);
        helpMenu->addAction(actionAbout_KDAB);
        helpMenu->addAction(actionAbout_Qt);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionAbout_Hotspot->setText(QCoreApplication::translate("MainWindow", "About &Hotspot", nullptr));
        actionAbout_KDAB->setText(QCoreApplication::translate("MainWindow", "About &KDAB", nullptr));
        actionAbout_Qt->setText(QCoreApplication::translate("MainWindow", "About &Qt", nullptr));
        helpMenu->setTitle(QCoreApplication::translate("MainWindow", "&Help", nullptr));
        fileMenu->setTitle(QCoreApplication::translate("MainWindow", "&File", nullptr));
        settingsMenu->setTitle(QCoreApplication::translate("MainWindow", "Setti&ngs", nullptr));
        viewMenu->setTitle(QCoreApplication::translate("MainWindow", "&View", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
