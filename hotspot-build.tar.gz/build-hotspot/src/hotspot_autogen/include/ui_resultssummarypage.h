/********************************************************************************
** Form generated from reading UI file 'resultssummarypage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSSUMMARYPAGE_H
#define UI_RESULTSSUMMARYPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ResultsSummaryPage
{
public:
    QVBoxLayout *verticalLayout_6;
    QScrollArea *summaryScrollArea;
    QWidget *summaryScrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_11;
    QGroupBox *parserErrorsBox;
    QVBoxLayout *verticalLayout_12;
    QTreeView *parserErrorsView;
    QGroupBox *summaryGroupBox;
    QVBoxLayout *summaryBoxLayout;
    QLabel *summaryLabel;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *eventSourceLabel;
    QComboBox *eventSourceComboBox;
    QTreeView *topHotspotsTableView;
    QGroupBox *systemInfoGroupBox;
    QFormLayout *formLayout;
    QLabel *systemInfoLabel;

    void setupUi(QWidget *ResultsSummaryPage)
    {
        if (ResultsSummaryPage->objectName().isEmpty())
            ResultsSummaryPage->setObjectName(QString::fromUtf8("ResultsSummaryPage"));
        ResultsSummaryPage->resize(308, 502);
        verticalLayout_6 = new QVBoxLayout(ResultsSummaryPage);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, -1, 0, -1);
        summaryScrollArea = new QScrollArea(ResultsSummaryPage);
        summaryScrollArea->setObjectName(QString::fromUtf8("summaryScrollArea"));
        summaryScrollArea->setWidgetResizable(true);
        summaryScrollAreaWidgetContents = new QWidget();
        summaryScrollAreaWidgetContents->setObjectName(QString::fromUtf8("summaryScrollAreaWidgetContents"));
        summaryScrollAreaWidgetContents->setGeometry(QRect(0, 0, 283, 691));
        verticalLayout_11 = new QVBoxLayout(summaryScrollAreaWidgetContents);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        parserErrorsBox = new QGroupBox(summaryScrollAreaWidgetContents);
        parserErrorsBox->setObjectName(QString::fromUtf8("parserErrorsBox"));
        verticalLayout_12 = new QVBoxLayout(parserErrorsBox);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        parserErrorsView = new QTreeView(parserErrorsBox);
        parserErrorsView->setObjectName(QString::fromUtf8("parserErrorsView"));
        parserErrorsView->setRootIsDecorated(false);
        parserErrorsView->setUniformRowHeights(true);
        parserErrorsView->setHeaderHidden(true);

        verticalLayout_12->addWidget(parserErrorsView);


        verticalLayout_11->addWidget(parserErrorsBox);

        summaryGroupBox = new QGroupBox(summaryScrollAreaWidgetContents);
        summaryGroupBox->setObjectName(QString::fromUtf8("summaryGroupBox"));
        summaryBoxLayout = new QVBoxLayout(summaryGroupBox);
        summaryBoxLayout->setObjectName(QString::fromUtf8("summaryBoxLayout"));
        summaryLabel = new QLabel(summaryGroupBox);
        summaryLabel->setObjectName(QString::fromUtf8("summaryLabel"));
#if QT_CONFIG(tooltip)
        summaryLabel->setToolTip(QString::fromUtf8(""));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        summaryLabel->setStatusTip(QString::fromUtf8(""));
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(whatsthis)
        summaryLabel->setWhatsThis(QString::fromUtf8(""));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(accessibility)
        summaryLabel->setAccessibleName(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        summaryLabel->setAccessibleDescription(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
        summaryLabel->setText(QString::fromUtf8("summary text"));
        summaryLabel->setWordWrap(true);
        summaryLabel->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);

        summaryBoxLayout->addWidget(summaryLabel);


        verticalLayout_11->addWidget(summaryGroupBox);

        groupBox_2 = new QGroupBox(summaryScrollAreaWidgetContents);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_3 = new QVBoxLayout(groupBox_2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        widget = new QWidget(groupBox_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        eventSourceLabel = new QLabel(widget);
        eventSourceLabel->setObjectName(QString::fromUtf8("eventSourceLabel"));
        eventSourceLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(eventSourceLabel);

        eventSourceComboBox = new QComboBox(widget);
        eventSourceComboBox->setObjectName(QString::fromUtf8("eventSourceComboBox"));

        horizontalLayout->addWidget(eventSourceComboBox);


        verticalLayout_3->addWidget(widget);

        topHotspotsTableView = new QTreeView(groupBox_2);
        topHotspotsTableView->setObjectName(QString::fromUtf8("topHotspotsTableView"));
        topHotspotsTableView->setMinimumSize(QSize(1, 150));
        topHotspotsTableView->setAlternatingRowColors(true);
        topHotspotsTableView->setRootIsDecorated(false);
        topHotspotsTableView->setUniformRowHeights(true);

        verticalLayout_3->addWidget(topHotspotsTableView);


        verticalLayout_11->addWidget(groupBox_2);

        systemInfoGroupBox = new QGroupBox(summaryScrollAreaWidgetContents);
        systemInfoGroupBox->setObjectName(QString::fromUtf8("systemInfoGroupBox"));
        formLayout = new QFormLayout(systemInfoGroupBox);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        systemInfoLabel = new QLabel(systemInfoGroupBox);
        systemInfoLabel->setObjectName(QString::fromUtf8("systemInfoLabel"));
#if QT_CONFIG(tooltip)
        systemInfoLabel->setToolTip(QString::fromUtf8(""));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(statustip)
        systemInfoLabel->setStatusTip(QString::fromUtf8(""));
#endif // QT_CONFIG(statustip)
#if QT_CONFIG(whatsthis)
        systemInfoLabel->setWhatsThis(QString::fromUtf8(""));
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(accessibility)
        systemInfoLabel->setAccessibleName(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
#if QT_CONFIG(accessibility)
        systemInfoLabel->setAccessibleDescription(QString::fromUtf8(""));
#endif // QT_CONFIG(accessibility)
        systemInfoLabel->setText(QString::fromUtf8("system info"));
        systemInfoLabel->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);

        formLayout->setWidget(0, QFormLayout::LabelRole, systemInfoLabel);


        verticalLayout_11->addWidget(systemInfoGroupBox);

        summaryScrollArea->setWidget(summaryScrollAreaWidgetContents);

        verticalLayout_6->addWidget(summaryScrollArea);


        retranslateUi(ResultsSummaryPage);

        QMetaObject::connectSlotsByName(ResultsSummaryPage);
    } // setupUi

    void retranslateUi(QWidget *ResultsSummaryPage)
    {
#if QT_CONFIG(tooltip)
        ResultsSummaryPage->setToolTip(QCoreApplication::translate("ResultsSummaryPage", "Summary of the profile data analysis.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        parserErrorsBox->setToolTip(QCoreApplication::translate("ResultsSummaryPage", "Errors occurred parsing the data input. You may need to change the search paths to resolve errors for missing ELF files.", nullptr));
#endif // QT_CONFIG(tooltip)
        parserErrorsBox->setTitle(QCoreApplication::translate("ResultsSummaryPage", "Parser Errors", nullptr));
        summaryGroupBox->setTitle(QCoreApplication::translate("ResultsSummaryPage", "Summary", nullptr));
#if QT_CONFIG(tooltip)
        groupBox_2->setToolTip(QCoreApplication::translate("ResultsSummaryPage", "The hotspots found in the profile, i.e. the code that contributed the most samples.", nullptr));
#endif // QT_CONFIG(tooltip)
        groupBox_2->setTitle(QCoreApplication::translate("ResultsSummaryPage", "Top Hotspots", nullptr));
        eventSourceLabel->setText(QCoreApplication::translate("ResultsSummaryPage", "Event Source:", nullptr));
        systemInfoGroupBox->setTitle(QCoreApplication::translate("ResultsSummaryPage", "System Information", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ResultsSummaryPage: public Ui_ResultsSummaryPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSSUMMARYPAGE_H
