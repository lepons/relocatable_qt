/********************************************************************************
** Form generated from reading UI file 'startpage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STARTPAGE_H
#define UI_STARTPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StartPage
{
public:
    QVBoxLayout *verticalLayout_9;
    QLabel *welcomeText;
    QStackedWidget *loadStack;
    QWidget *openFilePage;
    QVBoxLayout *verticalLayout_10;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QWidget *widget_3;
    QGridLayout *gridLayout;
    QPushButton *openFileButton;
    QToolButton *pathSettings;
    QPushButton *recordDataButton;
    QSpacerItem *horizontalSpacer_4;
    QLabel *loadingResultsErrorLabel;
    QWidget *parseProgressPage;
    QVBoxLayout *verticalLayout_8;
    QLabel *loadingResultsLabel;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QProgressBar *openFileProgressBar;
    QToolButton *stopParseButton;
    QSpacerItem *horizontalSpacer_2;

    void setupUi(QWidget *StartPage)
    {
        if (StartPage->objectName().isEmpty())
            StartPage->setObjectName(QString::fromUtf8("StartPage"));
        StartPage->resize(1081, 340);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(StartPage->sizePolicy().hasHeightForWidth());
        StartPage->setSizePolicy(sizePolicy);
        verticalLayout_9 = new QVBoxLayout(StartPage);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        welcomeText = new QLabel(StartPage);
        welcomeText->setObjectName(QString::fromUtf8("welcomeText"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(2);
        sizePolicy1.setHeightForWidth(welcomeText->sizePolicy().hasHeightForWidth());
        welcomeText->setSizePolicy(sizePolicy1);
        welcomeText->setTextFormat(Qt::RichText);
        welcomeText->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        welcomeText->setMargin(20);

        verticalLayout_9->addWidget(welcomeText);

        loadStack = new QStackedWidget(StartPage);
        loadStack->setObjectName(QString::fromUtf8("loadStack"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(2);
        sizePolicy2.setHeightForWidth(loadStack->sizePolicy().hasHeightForWidth());
        loadStack->setSizePolicy(sizePolicy2);
        openFilePage = new QWidget();
        openFilePage->setObjectName(QString::fromUtf8("openFilePage"));
        verticalLayout_10 = new QVBoxLayout(openFilePage);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        widget_2 = new QWidget(openFilePage);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_2 = new QHBoxLayout(widget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        gridLayout = new QGridLayout(widget_3);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        openFileButton = new QPushButton(widget_3);
        openFileButton->setObjectName(QString::fromUtf8("openFileButton"));
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("document-open");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        openFileButton->setIcon(icon);
        openFileButton->setAutoDefault(true);

        gridLayout->addWidget(openFileButton, 0, 0, 1, 1);

        pathSettings = new QToolButton(widget_3);
        pathSettings->setObjectName(QString::fromUtf8("pathSettings"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(pathSettings->sizePolicy().hasHeightForWidth());
        pathSettings->setSizePolicy(sizePolicy3);
        QIcon icon1;
        iconThemeName = QString::fromUtf8("configure");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon1 = QIcon::fromTheme(iconThemeName);
        } else {
            icon1.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        pathSettings->setIcon(icon1);
        pathSettings->setPopupMode(QToolButton::MenuButtonPopup);

        gridLayout->addWidget(pathSettings, 0, 1, 1, 1);

        recordDataButton = new QPushButton(widget_3);
        recordDataButton->setObjectName(QString::fromUtf8("recordDataButton"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(recordDataButton->sizePolicy().hasHeightForWidth());
        recordDataButton->setSizePolicy(sizePolicy4);
        QIcon icon2;
        iconThemeName = QString::fromUtf8("media-record");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon2 = QIcon::fromTheme(iconThemeName);
        } else {
            icon2.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        recordDataButton->setIcon(icon2);
        recordDataButton->setAutoDefault(true);

        gridLayout->addWidget(recordDataButton, 1, 0, 1, 2);


        horizontalLayout_2->addWidget(widget_3);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        verticalLayout_10->addWidget(widget_2);

        loadingResultsErrorLabel = new QLabel(openFilePage);
        loadingResultsErrorLabel->setObjectName(QString::fromUtf8("loadingResultsErrorLabel"));
        loadingResultsErrorLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_10->addWidget(loadingResultsErrorLabel);

        loadStack->addWidget(openFilePage);
        parseProgressPage = new QWidget();
        parseProgressPage->setObjectName(QString::fromUtf8("parseProgressPage"));
        verticalLayout_8 = new QVBoxLayout(parseProgressPage);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        loadingResultsLabel = new QLabel(parseProgressPage);
        loadingResultsLabel->setObjectName(QString::fromUtf8("loadingResultsLabel"));
        loadingResultsLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(loadingResultsLabel);

        widget = new QWidget(parseProgressPage);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(355, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        openFileProgressBar = new QProgressBar(widget);
        openFileProgressBar->setObjectName(QString::fromUtf8("openFileProgressBar"));
        openFileProgressBar->setMaximum(0);
        openFileProgressBar->setValue(-1);

        horizontalLayout->addWidget(openFileProgressBar);

        stopParseButton = new QToolButton(widget);
        stopParseButton->setObjectName(QString::fromUtf8("stopParseButton"));
        QIcon icon3;
        iconThemeName = QString::fromUtf8("process-stop");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon3 = QIcon::fromTheme(iconThemeName);
        } else {
            icon3.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        stopParseButton->setIcon(icon3);
        stopParseButton->setToolButtonStyle(Qt::ToolButtonIconOnly);
        stopParseButton->setAutoRaise(true);

        horizontalLayout->addWidget(stopParseButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);


        verticalLayout_8->addWidget(widget);

        loadStack->addWidget(parseProgressPage);

        verticalLayout_9->addWidget(loadStack, 0, Qt::AlignTop);


        retranslateUi(StartPage);

        loadStack->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(StartPage);
    } // setupUi

    void retranslateUi(QWidget *StartPage)
    {
        welcomeText->setText(QCoreApplication::translate("StartPage", "<html><head/><body><p><span style=\" font-size:28pt;\">Welcome to Hotspot,</span></p><p><span style=\" font-size:28pt;\">the performance profiler for Linux!</span></p></body></html>", nullptr));
#if QT_CONFIG(tooltip)
        openFileButton->setToolTip(QCoreApplication::translate("StartPage", "Open a perf.data file", nullptr));
#endif // QT_CONFIG(tooltip)
        openFileButton->setText(QCoreApplication::translate("StartPage", "Open File", nullptr));
#if QT_CONFIG(tooltip)
        pathSettings->setToolTip(QCoreApplication::translate("StartPage", "Configure hotspot settings to properly load data files from embedded systems or remote machines", nullptr));
#endif // QT_CONFIG(tooltip)
        pathSettings->setText(QCoreApplication::translate("StartPage", "...", nullptr));
#if QT_CONFIG(tooltip)
        recordDataButton->setToolTip(QCoreApplication::translate("StartPage", "Record perf data", nullptr));
#endif // QT_CONFIG(tooltip)
        recordDataButton->setText(QCoreApplication::translate("StartPage", "Record Data", nullptr));
        loadingResultsErrorLabel->setText(QString());
        loadingResultsLabel->setText(QCoreApplication::translate("StartPage", "Loading Results...", nullptr));
#if QT_CONFIG(tooltip)
        stopParseButton->setToolTip(QCoreApplication::translate("StartPage", "Stop the parse process and go back to the start page.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(shortcut)
        stopParseButton->setShortcut(QCoreApplication::translate("StartPage", "Esc", nullptr));
#endif // QT_CONFIG(shortcut)
        (void)StartPage;
    } // retranslateUi

};

namespace Ui {
    class StartPage: public Ui_StartPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STARTPAGE_H
