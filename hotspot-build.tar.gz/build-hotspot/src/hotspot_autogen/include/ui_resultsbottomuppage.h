/********************************************************************************
** Form generated from reading UI file 'resultsbottomuppage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSBOTTOMUPPAGE_H
#define UI_RESULTSBOTTOMUPPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ResultsBottomUpPage
{
public:
    QVBoxLayout *bottomUpVerticalLayout;
    QLineEdit *bottomUpSearch;
    QTreeView *bottomUpTreeView;

    void setupUi(QWidget *ResultsBottomUpPage)
    {
        if (ResultsBottomUpPage->objectName().isEmpty())
            ResultsBottomUpPage->setObjectName(QString::fromUtf8("ResultsBottomUpPage"));
        ResultsBottomUpPage->resize(256, 199);
        bottomUpVerticalLayout = new QVBoxLayout(ResultsBottomUpPage);
        bottomUpVerticalLayout->setObjectName(QString::fromUtf8("bottomUpVerticalLayout"));
        bottomUpVerticalLayout->setContentsMargins(0, 0, 0, 0);
        bottomUpSearch = new QLineEdit(ResultsBottomUpPage);
        bottomUpSearch->setObjectName(QString::fromUtf8("bottomUpSearch"));

        bottomUpVerticalLayout->addWidget(bottomUpSearch);

        bottomUpTreeView = new QTreeView(ResultsBottomUpPage);
        bottomUpTreeView->setObjectName(QString::fromUtf8("bottomUpTreeView"));
        bottomUpTreeView->setAlternatingRowColors(true);
        bottomUpTreeView->setUniformRowHeights(true);
        bottomUpTreeView->setSortingEnabled(true);

        bottomUpVerticalLayout->addWidget(bottomUpTreeView);


        retranslateUi(ResultsBottomUpPage);

        QMetaObject::connectSlotsByName(ResultsBottomUpPage);
    } // setupUi

    void retranslateUi(QWidget *ResultsBottomUpPage)
    {
#if QT_CONFIG(tooltip)
        ResultsBottomUpPage->setToolTip(QCoreApplication::translate("ResultsBottomUpPage", "Inspect the profile data samples in an aggregated view, showing the bottom-up call-graph tree.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        bottomUpSearch->setToolTip(QCoreApplication::translate("ResultsBottomUpPage", "Filter the call graph tree.", nullptr));
#endif // QT_CONFIG(tooltip)
    } // retranslateUi

};

namespace Ui {
    class ResultsBottomUpPage: public Ui_ResultsBottomUpPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSBOTTOMUPPAGE_H
