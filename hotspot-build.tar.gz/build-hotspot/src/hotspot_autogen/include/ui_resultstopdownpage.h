/********************************************************************************
** Form generated from reading UI file 'resultstopdownpage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSTOPDOWNPAGE_H
#define UI_RESULTSTOPDOWNPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ResultsTopDownPage
{
public:
    QVBoxLayout *verticalLayout_2;
    QLineEdit *topDownSearch;
    QTreeView *topDownTreeView;

    void setupUi(QWidget *ResultsTopDownPage)
    {
        if (ResultsTopDownPage->objectName().isEmpty())
            ResultsTopDownPage->setObjectName(QString::fromUtf8("ResultsTopDownPage"));
        ResultsTopDownPage->resize(256, 199);
        verticalLayout_2 = new QVBoxLayout(ResultsTopDownPage);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        topDownSearch = new QLineEdit(ResultsTopDownPage);
        topDownSearch->setObjectName(QString::fromUtf8("topDownSearch"));

        verticalLayout_2->addWidget(topDownSearch);

        topDownTreeView = new QTreeView(ResultsTopDownPage);
        topDownTreeView->setObjectName(QString::fromUtf8("topDownTreeView"));
        topDownTreeView->setAlternatingRowColors(true);
        topDownTreeView->setUniformRowHeights(true);
        topDownTreeView->setSortingEnabled(true);

        verticalLayout_2->addWidget(topDownTreeView);


        retranslateUi(ResultsTopDownPage);

        QMetaObject::connectSlotsByName(ResultsTopDownPage);
    } // setupUi

    void retranslateUi(QWidget *ResultsTopDownPage)
    {
#if QT_CONFIG(tooltip)
        ResultsTopDownPage->setToolTip(QCoreApplication::translate("ResultsTopDownPage", "Inspect the profile data samples in an aggregated view, showing the top-down call-graph tree.", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        topDownSearch->setToolTip(QCoreApplication::translate("ResultsTopDownPage", "Filter the call graph tree.", nullptr));
#endif // QT_CONFIG(tooltip)
    } // retranslateUi

};

namespace Ui {
    class ResultsTopDownPage: public Ui_ResultsTopDownPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSTOPDOWNPAGE_H
