/********************************************************************************
** Form generated from reading UI file 'resultspage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSPAGE_H
#define UI_RESULTSPAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "kmessagewidget.h"

QT_BEGIN_NAMESPACE

class Ui_ResultsPage
{
public:
    QVBoxLayout *verticalLayout_3;
    QSplitter *splitter;
    QWidget *resultsWidget;
    QVBoxLayout *verticalLayout_2;
    KMessageWidget *errorWidget;
    KMessageWidget *lostMessage;
    QTabWidget *resultsTabWidget;
    QWidget *timeLineArea;
    QVBoxLayout *verticalLayout;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QToolButton *timeLineEventFilterButton;
    QSpacerItem *horizontalSpacer;
    QLineEdit *timeLineSearch;
    QLabel *label_2;
    QComboBox *timeLineEventSource;
    QTreeView *timeLineView;

    void setupUi(QWidget *ResultsPage)
    {
        if (ResultsPage->objectName().isEmpty())
            ResultsPage->setObjectName(QString::fromUtf8("ResultsPage"));
        ResultsPage->resize(744, 510);
        verticalLayout_3 = new QVBoxLayout(ResultsPage);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        splitter = new QSplitter(ResultsPage);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        resultsWidget = new QWidget(splitter);
        resultsWidget->setObjectName(QString::fromUtf8("resultsWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(resultsWidget->sizePolicy().hasHeightForWidth());
        resultsWidget->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(resultsWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        errorWidget = new KMessageWidget(resultsWidget);
        errorWidget->setObjectName(QString::fromUtf8("errorWidget"));
        errorWidget->setWordWrap(false);
        errorWidget->setMessageType(KMessageWidget::Warning);

        verticalLayout_2->addWidget(errorWidget);

        lostMessage = new KMessageWidget(resultsWidget);
        lostMessage->setObjectName(QString::fromUtf8("lostMessage"));

        verticalLayout_2->addWidget(lostMessage);

        resultsTabWidget = new QTabWidget(resultsWidget);
        resultsTabWidget->setObjectName(QString::fromUtf8("resultsTabWidget"));
        resultsTabWidget->setDocumentMode(true);

        verticalLayout_2->addWidget(resultsTabWidget);

        splitter->addWidget(resultsWidget);
        timeLineArea = new QWidget(splitter);
        timeLineArea->setObjectName(QString::fromUtf8("timeLineArea"));
        verticalLayout = new QVBoxLayout(timeLineArea);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, -1, 0, 0);
        widget_2 = new QWidget(timeLineArea);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        timeLineEventFilterButton = new QToolButton(widget_2);
        timeLineEventFilterButton->setObjectName(QString::fromUtf8("timeLineEventFilterButton"));
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("view-filter");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        timeLineEventFilterButton->setIcon(icon);
        timeLineEventFilterButton->setPopupMode(QToolButton::InstantPopup);
        timeLineEventFilterButton->setAutoRaise(true);

        horizontalLayout->addWidget(timeLineEventFilterButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        timeLineSearch = new QLineEdit(widget_2);
        timeLineSearch->setObjectName(QString::fromUtf8("timeLineSearch"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(timeLineSearch->sizePolicy().hasHeightForWidth());
        timeLineSearch->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(timeLineSearch);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(label_2);

        timeLineEventSource = new QComboBox(widget_2);
        timeLineEventSource->setObjectName(QString::fromUtf8("timeLineEventSource"));

        horizontalLayout->addWidget(timeLineEventSource);


        verticalLayout->addWidget(widget_2);

        timeLineView = new QTreeView(timeLineArea);
        timeLineView->setObjectName(QString::fromUtf8("timeLineView"));
        timeLineView->setAlternatingRowColors(true);
        timeLineView->setRootIsDecorated(false);
        timeLineView->setUniformRowHeights(true);
        timeLineView->setItemsExpandable(false);

        verticalLayout->addWidget(timeLineView);

        splitter->addWidget(timeLineArea);

        verticalLayout_3->addWidget(splitter);


        retranslateUi(ResultsPage);

        resultsTabWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(ResultsPage);
    } // setupUi

    void retranslateUi(QWidget *ResultsPage)
    {
        label->setText(QCoreApplication::translate("ResultsPage", "Time Line", nullptr));
#if QT_CONFIG(tooltip)
        timeLineEventFilterButton->setToolTip(QCoreApplication::translate("ResultsPage", "Configure event filters", nullptr));
#endif // QT_CONFIG(tooltip)
        timeLineEventFilterButton->setText(QCoreApplication::translate("ResultsPage", "Filter", nullptr));
#if QT_CONFIG(tooltip)
        timeLineSearch->setToolTip(QCoreApplication::translate("ResultsPage", "<html><head/><body><p>Search event timeline for threads by name or thread id.</p></body></html>", nullptr));
#endif // QT_CONFIG(tooltip)
        label_2->setText(QCoreApplication::translate("ResultsPage", "Event Source:", nullptr));
        (void)ResultsPage;
    } // retranslateUi

};

namespace Ui {
    class ResultsPage: public Ui_ResultsPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSPAGE_H
