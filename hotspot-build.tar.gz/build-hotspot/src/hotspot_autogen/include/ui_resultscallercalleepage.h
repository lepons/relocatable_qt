/********************************************************************************
** Form generated from reading UI file 'resultscallercalleepage.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESULTSCALLERCALLEEPAGE_H
#define UI_RESULTSCALLERCALLEEPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ResultsCallerCalleePage
{
public:
    QVBoxLayout *verticalLayout_4;
    QLineEdit *callerCalleeFilter;
    QSplitter *splitter_2;
    QTreeView *callerCalleeTableView;
    QSplitter *splitter;
    QTreeView *callersView;
    QTreeView *calleesView;
    QTreeView *sourceMapView;

    void setupUi(QWidget *ResultsCallerCalleePage)
    {
        if (ResultsCallerCalleePage->objectName().isEmpty())
            ResultsCallerCalleePage->setObjectName(QString::fromUtf8("ResultsCallerCalleePage"));
        ResultsCallerCalleePage->resize(768, 391);
        verticalLayout_4 = new QVBoxLayout(ResultsCallerCalleePage);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        callerCalleeFilter = new QLineEdit(ResultsCallerCalleePage);
        callerCalleeFilter->setObjectName(QString::fromUtf8("callerCalleeFilter"));

        verticalLayout_4->addWidget(callerCalleeFilter);

        splitter_2 = new QSplitter(ResultsCallerCalleePage);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Vertical);
        callerCalleeTableView = new QTreeView(splitter_2);
        callerCalleeTableView->setObjectName(QString::fromUtf8("callerCalleeTableView"));
        callerCalleeTableView->setAlternatingRowColors(true);
        callerCalleeTableView->setRootIsDecorated(false);
        callerCalleeTableView->setUniformRowHeights(true);
        callerCalleeTableView->setSortingEnabled(true);
        splitter_2->addWidget(callerCalleeTableView);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        callersView = new QTreeView(splitter);
        callersView->setObjectName(QString::fromUtf8("callersView"));
        callersView->setAlternatingRowColors(true);
        callersView->setRootIsDecorated(false);
        callersView->setUniformRowHeights(true);
        callersView->setSortingEnabled(true);
        splitter->addWidget(callersView);
        calleesView = new QTreeView(splitter);
        calleesView->setObjectName(QString::fromUtf8("calleesView"));
        calleesView->setAlternatingRowColors(true);
        calleesView->setRootIsDecorated(false);
        calleesView->setUniformRowHeights(true);
        calleesView->setSortingEnabled(true);
        splitter->addWidget(calleesView);
        sourceMapView = new QTreeView(splitter);
        sourceMapView->setObjectName(QString::fromUtf8("sourceMapView"));
        sourceMapView->setAlternatingRowColors(true);
        sourceMapView->setRootIsDecorated(false);
        sourceMapView->setUniformRowHeights(true);
        sourceMapView->setSortingEnabled(true);
        splitter->addWidget(sourceMapView);
        splitter_2->addWidget(splitter);

        verticalLayout_4->addWidget(splitter_2);


        retranslateUi(ResultsCallerCalleePage);

        QMetaObject::connectSlotsByName(ResultsCallerCalleePage);
    } // setupUi

    void retranslateUi(QWidget *ResultsCallerCalleePage)
    {
#if QT_CONFIG(tooltip)
        ResultsCallerCalleePage->setToolTip(QCoreApplication::translate("ResultsCallerCalleePage", "Show the profile data in a flat aggregated caller/callee table view.", nullptr));
#endif // QT_CONFIG(tooltip)
    } // retranslateUi

};

namespace Ui {
    class ResultsCallerCalleePage: public Ui_ResultsCallerCalleePage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESULTSCALLERCALLEEPAGE_H
