/****************************************************************************
** Meta object code from reading C++ file 'treemodel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "treemodel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'treemodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AbstractTreeModel_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AbstractTreeModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AbstractTreeModel_t qt_meta_stringdata_AbstractTreeModel = {
    {
QT_MOC_LITERAL(0, 0, 17) // "AbstractTreeModel"

    },
    "AbstractTreeModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AbstractTreeModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void AbstractTreeModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject AbstractTreeModel::staticMetaObject = { {
    QMetaObject::SuperData::link<QAbstractItemModel::staticMetaObject>(),
    qt_meta_stringdata_AbstractTreeModel.data,
    qt_meta_data_AbstractTreeModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *AbstractTreeModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AbstractTreeModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AbstractTreeModel.stringdata0))
        return static_cast<void*>(this);
    return QAbstractItemModel::qt_metacast(_clname);
}

int AbstractTreeModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractItemModel::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_BottomUpModel_t {
    QByteArrayData data[1];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_BottomUpModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_BottomUpModel_t qt_meta_stringdata_BottomUpModel = {
    {
QT_MOC_LITERAL(0, 0, 13) // "BottomUpModel"

    },
    "BottomUpModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_BottomUpModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void BottomUpModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject BottomUpModel::staticMetaObject = { {
    QMetaObject::SuperData::link<CostTreeModel<Data::BottomUpResults,BottomUpModel>::staticMetaObject>(),
    qt_meta_stringdata_BottomUpModel.data,
    qt_meta_data_BottomUpModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *BottomUpModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BottomUpModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_BottomUpModel.stringdata0))
        return static_cast<void*>(this);
    return CostTreeModel<Data::BottomUpResults,BottomUpModel>::qt_metacast(_clname);
}

int BottomUpModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CostTreeModel<Data::BottomUpResults,BottomUpModel>::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_TopDownModel_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TopDownModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TopDownModel_t qt_meta_stringdata_TopDownModel = {
    {
QT_MOC_LITERAL(0, 0, 12) // "TopDownModel"

    },
    "TopDownModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TopDownModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void TopDownModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject TopDownModel::staticMetaObject = { {
    QMetaObject::SuperData::link<CostTreeModel<Data::TopDownResults,TopDownModel>::staticMetaObject>(),
    qt_meta_stringdata_TopDownModel.data,
    qt_meta_data_TopDownModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TopDownModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TopDownModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TopDownModel.stringdata0))
        return static_cast<void*>(this);
    return CostTreeModel<Data::TopDownResults,TopDownModel>::qt_metacast(_clname);
}

int TopDownModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = CostTreeModel<Data::TopDownResults,TopDownModel>::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
