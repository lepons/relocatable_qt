/****************************************************************************
** Meta object code from reading C++ file 'callercalleemodel.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "callercalleemodel.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'callercalleemodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CallerCalleeModel_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CallerCalleeModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CallerCalleeModel_t qt_meta_stringdata_CallerCalleeModel = {
    {
QT_MOC_LITERAL(0, 0, 17) // "CallerCalleeModel"

    },
    "CallerCalleeModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CallerCalleeModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void CallerCalleeModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject CallerCalleeModel::staticMetaObject = { {
    QMetaObject::SuperData::link<HashModel<Data::CallerCalleeEntryMap,CallerCalleeModel>::staticMetaObject>(),
    qt_meta_stringdata_CallerCalleeModel.data,
    qt_meta_data_CallerCalleeModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CallerCalleeModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CallerCalleeModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CallerCalleeModel.stringdata0))
        return static_cast<void*>(this);
    return HashModel<Data::CallerCalleeEntryMap,CallerCalleeModel>::qt_metacast(_clname);
}

int CallerCalleeModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = HashModel<Data::CallerCalleeEntryMap,CallerCalleeModel>::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_CallerModel_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CallerModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CallerModel_t qt_meta_stringdata_CallerModel = {
    {
QT_MOC_LITERAL(0, 0, 11) // "CallerModel"

    },
    "CallerModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CallerModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void CallerModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject CallerModel::staticMetaObject = { {
    QMetaObject::SuperData::link<SymbolCostModelImpl<CallerModel>::staticMetaObject>(),
    qt_meta_stringdata_CallerModel.data,
    qt_meta_data_CallerModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CallerModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CallerModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CallerModel.stringdata0))
        return static_cast<void*>(this);
    return SymbolCostModelImpl<CallerModel>::qt_metacast(_clname);
}

int CallerModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SymbolCostModelImpl<CallerModel>::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_CalleeModel_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CalleeModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CalleeModel_t qt_meta_stringdata_CalleeModel = {
    {
QT_MOC_LITERAL(0, 0, 11) // "CalleeModel"

    },
    "CalleeModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CalleeModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void CalleeModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject CalleeModel::staticMetaObject = { {
    QMetaObject::SuperData::link<SymbolCostModelImpl<CalleeModel>::staticMetaObject>(),
    qt_meta_stringdata_CalleeModel.data,
    qt_meta_data_CalleeModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CalleeModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CalleeModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CalleeModel.stringdata0))
        return static_cast<void*>(this);
    return SymbolCostModelImpl<CalleeModel>::qt_metacast(_clname);
}

int CalleeModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SymbolCostModelImpl<CalleeModel>::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_SourceMapModel_t {
    QByteArrayData data[1];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SourceMapModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SourceMapModel_t qt_meta_stringdata_SourceMapModel = {
    {
QT_MOC_LITERAL(0, 0, 14) // "SourceMapModel"

    },
    "SourceMapModel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SourceMapModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void SourceMapModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject SourceMapModel::staticMetaObject = { {
    QMetaObject::SuperData::link<LocationCostModelImpl<SourceMapModel>::staticMetaObject>(),
    qt_meta_stringdata_SourceMapModel.data,
    qt_meta_data_SourceMapModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SourceMapModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SourceMapModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SourceMapModel.stringdata0))
        return static_cast<void*>(this);
    return LocationCostModelImpl<SourceMapModel>::qt_metacast(_clname);
}

int SourceMapModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LocationCostModelImpl<SourceMapModel>::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
