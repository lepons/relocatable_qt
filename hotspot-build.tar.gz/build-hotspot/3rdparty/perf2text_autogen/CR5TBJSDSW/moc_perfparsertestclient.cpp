/****************************************************************************
** Meta object code from reading C++ file 'perfparsertestclient.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "perfparser/tests/auto/shared/perfparsertestclient.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'perfparsertestclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PerfParserTestClient_t {
    QByteArrayData data[18];
    char stringdata0[261];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PerfParserTestClient_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PerfParserTestClient_t qt_meta_stringdata_PerfParserTestClient = {
    {
QT_MOC_LITERAL(0, 0, 20), // "PerfParserTestClient"
QT_MOC_LITERAL(1, 21, 9), // "EventType"
QT_MOC_LITERAL(2, 31, 11), // "ThreadStart"
QT_MOC_LITERAL(3, 43, 9), // "ThreadEnd"
QT_MOC_LITERAL(4, 53, 7), // "Command"
QT_MOC_LITERAL(5, 61, 18), // "LocationDefinition"
QT_MOC_LITERAL(6, 80, 16), // "SymbolDefinition"
QT_MOC_LITERAL(7, 97, 16), // "StringDefinition"
QT_MOC_LITERAL(8, 114, 14), // "LostDefinition"
QT_MOC_LITERAL(9, 129, 18), // "FeaturesDefinition"
QT_MOC_LITERAL(10, 148, 5), // "Error"
QT_MOC_LITERAL(11, 154, 8), // "Progress"
QT_MOC_LITERAL(12, 163, 16), // "TracePointFormat"
QT_MOC_LITERAL(13, 180, 20), // "AttributesDefinition"
QT_MOC_LITERAL(14, 201, 23), // "ContextSwitchDefinition"
QT_MOC_LITERAL(15, 225, 6), // "Sample"
QT_MOC_LITERAL(16, 232, 16), // "TracePointSample"
QT_MOC_LITERAL(17, 249, 11) // "InvalidType"

    },
    "PerfParserTestClient\0EventType\0"
    "ThreadStart\0ThreadEnd\0Command\0"
    "LocationDefinition\0SymbolDefinition\0"
    "StringDefinition\0LostDefinition\0"
    "FeaturesDefinition\0Error\0Progress\0"
    "TracePointFormat\0AttributesDefinition\0"
    "ContextSwitchDefinition\0Sample\0"
    "TracePointSample\0InvalidType"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PerfParserTestClient[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, alias, flags, count, data
       1,    1, 0x0,   16,   19,

 // enum data: key, value
       2, uint(PerfParserTestClient::ThreadStart),
       3, uint(PerfParserTestClient::ThreadEnd),
       4, uint(PerfParserTestClient::Command),
       5, uint(PerfParserTestClient::LocationDefinition),
       6, uint(PerfParserTestClient::SymbolDefinition),
       7, uint(PerfParserTestClient::StringDefinition),
       8, uint(PerfParserTestClient::LostDefinition),
       9, uint(PerfParserTestClient::FeaturesDefinition),
      10, uint(PerfParserTestClient::Error),
      11, uint(PerfParserTestClient::Progress),
      12, uint(PerfParserTestClient::TracePointFormat),
      13, uint(PerfParserTestClient::AttributesDefinition),
      14, uint(PerfParserTestClient::ContextSwitchDefinition),
      15, uint(PerfParserTestClient::Sample),
      16, uint(PerfParserTestClient::TracePointSample),
      17, uint(PerfParserTestClient::InvalidType),

       0        // eod
};

void PerfParserTestClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject PerfParserTestClient::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_PerfParserTestClient.data,
    qt_meta_data_PerfParserTestClient,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PerfParserTestClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PerfParserTestClient::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PerfParserTestClient.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int PerfParserTestClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
