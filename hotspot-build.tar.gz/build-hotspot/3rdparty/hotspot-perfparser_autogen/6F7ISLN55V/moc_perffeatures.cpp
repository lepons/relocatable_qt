/****************************************************************************
** Meta object code from reading C++ file 'perffeatures.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "perfparser/app/perffeatures.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'perffeatures.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PerfCompressed_t {
    QByteArrayData data[5];
    char stringdata0[64];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PerfCompressed_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PerfCompressed_t qt_meta_stringdata_PerfCompressed = {
    {
QT_MOC_LITERAL(0, 0, 14), // "PerfCompressed"
QT_MOC_LITERAL(1, 15, 4), // "Type"
QT_MOC_LITERAL(2, 20, 14), // "PERF_COMP_NONE"
QT_MOC_LITERAL(3, 35, 14), // "PERF_COMP_ZSTD"
QT_MOC_LITERAL(4, 50, 13) // "PERF_COMP_MAX"

    },
    "PerfCompressed\0Type\0PERF_COMP_NONE\0"
    "PERF_COMP_ZSTD\0PERF_COMP_MAX"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PerfCompressed[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, alias, flags, count, data
       1,    1, 0x0,    3,   19,

 // enum data: key, value
       2, uint(PerfCompressed::PERF_COMP_NONE),
       3, uint(PerfCompressed::PERF_COMP_ZSTD),
       4, uint(PerfCompressed::PERF_COMP_MAX),

       0        // eod
};

QT_INIT_METAOBJECT const QMetaObject PerfCompressed::staticMetaObject = { {
    nullptr,
    qt_meta_stringdata_PerfCompressed.data,
    qt_meta_data_PerfCompressed,
    nullptr,
    nullptr,
    nullptr
} };

QT_WARNING_POP
QT_END_MOC_NAMESPACE
