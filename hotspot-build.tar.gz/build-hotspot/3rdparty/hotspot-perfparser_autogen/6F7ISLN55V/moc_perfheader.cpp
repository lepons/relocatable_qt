/****************************************************************************
** Meta object code from reading C++ file 'perfheader.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "perfparser/app/perfheader.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'perfheader.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PerfHeader_t {
    QByteArrayData data[38];
    char stringdata0[364];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PerfHeader_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PerfHeader_t qt_meta_stringdata_PerfHeader = {
    {
QT_MOC_LITERAL(0, 0, 10), // "PerfHeader"
QT_MOC_LITERAL(1, 11, 8), // "finished"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 5), // "error"
QT_MOC_LITERAL(4, 27, 4), // "read"
QT_MOC_LITERAL(5, 32, 7), // "Feature"
QT_MOC_LITERAL(6, 40, 8), // "RESERVED"
QT_MOC_LITERAL(7, 49, 13), // "FIRST_FEATURE"
QT_MOC_LITERAL(8, 63, 12), // "TRACING_DATA"
QT_MOC_LITERAL(9, 76, 8), // "BUILD_ID"
QT_MOC_LITERAL(10, 85, 8), // "HOSTNAME"
QT_MOC_LITERAL(11, 94, 9), // "OSRELEASE"
QT_MOC_LITERAL(12, 104, 7), // "VERSION"
QT_MOC_LITERAL(13, 112, 4), // "ARCH"
QT_MOC_LITERAL(14, 117, 6), // "NRCPUS"
QT_MOC_LITERAL(15, 124, 7), // "CPUDESC"
QT_MOC_LITERAL(16, 132, 5), // "CPUID"
QT_MOC_LITERAL(17, 138, 9), // "TOTAL_MEM"
QT_MOC_LITERAL(18, 148, 7), // "CMDLINE"
QT_MOC_LITERAL(19, 156, 10), // "EVENT_DESC"
QT_MOC_LITERAL(20, 167, 12), // "CPU_TOPOLOGY"
QT_MOC_LITERAL(21, 180, 13), // "NUMA_TOPOLOGY"
QT_MOC_LITERAL(22, 194, 12), // "BRANCH_STACK"
QT_MOC_LITERAL(23, 207, 12), // "PMU_MAPPINGS"
QT_MOC_LITERAL(24, 220, 10), // "GROUP_DESC"
QT_MOC_LITERAL(25, 231, 8), // "AUXTRACE"
QT_MOC_LITERAL(26, 240, 4), // "STAT"
QT_MOC_LITERAL(27, 245, 5), // "CACHE"
QT_MOC_LITERAL(28, 251, 11), // "SAMPLE_TIME"
QT_MOC_LITERAL(29, 263, 12), // "MEM_TOPOLOGY"
QT_MOC_LITERAL(30, 276, 7), // "CLOCKID"
QT_MOC_LITERAL(31, 284, 10), // "DIR_FORMAT"
QT_MOC_LITERAL(32, 295, 13), // "BPF_PROG_INFO"
QT_MOC_LITERAL(33, 309, 7), // "BPF_BTF"
QT_MOC_LITERAL(34, 317, 10), // "COMPRESSED"
QT_MOC_LITERAL(35, 328, 12), // "CPU_PMU_CAPS"
QT_MOC_LITERAL(36, 341, 12), // "LAST_FEATURE"
QT_MOC_LITERAL(37, 354, 9) // "FEAT_BITS"

    },
    "PerfHeader\0finished\0\0error\0read\0Feature\0"
    "RESERVED\0FIRST_FEATURE\0TRACING_DATA\0"
    "BUILD_ID\0HOSTNAME\0OSRELEASE\0VERSION\0"
    "ARCH\0NRCPUS\0CPUDESC\0CPUID\0TOTAL_MEM\0"
    "CMDLINE\0EVENT_DESC\0CPU_TOPOLOGY\0"
    "NUMA_TOPOLOGY\0BRANCH_STACK\0PMU_MAPPINGS\0"
    "GROUP_DESC\0AUXTRACE\0STAT\0CACHE\0"
    "SAMPLE_TIME\0MEM_TOPOLOGY\0CLOCKID\0"
    "DIR_FORMAT\0BPF_PROG_INFO\0BPF_BTF\0"
    "COMPRESSED\0CPU_PMU_CAPS\0LAST_FEATURE\0"
    "FEAT_BITS"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PerfHeader[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       1,   32, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   29,    2, 0x06 /* Public */,
       3,    0,   30,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   31,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,

 // enums: name, alias, flags, count, data
       5,    5, 0x0,   32,   37,

 // enum data: key, value
       6, uint(PerfHeader::RESERVED),
       7, uint(PerfHeader::FIRST_FEATURE),
       8, uint(PerfHeader::TRACING_DATA),
       9, uint(PerfHeader::BUILD_ID),
      10, uint(PerfHeader::HOSTNAME),
      11, uint(PerfHeader::OSRELEASE),
      12, uint(PerfHeader::VERSION),
      13, uint(PerfHeader::ARCH),
      14, uint(PerfHeader::NRCPUS),
      15, uint(PerfHeader::CPUDESC),
      16, uint(PerfHeader::CPUID),
      17, uint(PerfHeader::TOTAL_MEM),
      18, uint(PerfHeader::CMDLINE),
      19, uint(PerfHeader::EVENT_DESC),
      20, uint(PerfHeader::CPU_TOPOLOGY),
      21, uint(PerfHeader::NUMA_TOPOLOGY),
      22, uint(PerfHeader::BRANCH_STACK),
      23, uint(PerfHeader::PMU_MAPPINGS),
      24, uint(PerfHeader::GROUP_DESC),
      25, uint(PerfHeader::AUXTRACE),
      26, uint(PerfHeader::STAT),
      27, uint(PerfHeader::CACHE),
      28, uint(PerfHeader::SAMPLE_TIME),
      29, uint(PerfHeader::MEM_TOPOLOGY),
      30, uint(PerfHeader::CLOCKID),
      31, uint(PerfHeader::DIR_FORMAT),
      32, uint(PerfHeader::BPF_PROG_INFO),
      33, uint(PerfHeader::BPF_BTF),
      34, uint(PerfHeader::COMPRESSED),
      35, uint(PerfHeader::CPU_PMU_CAPS),
      36, uint(PerfHeader::LAST_FEATURE),
      37, uint(PerfHeader::FEAT_BITS),

       0        // eod
};

void PerfHeader::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PerfHeader *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->finished(); break;
        case 1: _t->error(); break;
        case 2: _t->read(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PerfHeader::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfHeader::finished)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PerfHeader::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PerfHeader::error)) {
                *result = 1;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject PerfHeader::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_PerfHeader.data,
    qt_meta_data_PerfHeader,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PerfHeader::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PerfHeader::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PerfHeader.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int PerfHeader::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void PerfHeader::finished()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void PerfHeader::error()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
